package com.portfolio.GEL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GelApplication {

	public static void main(String[] args) {
		SpringApplication.run(GelApplication.class, args);
	}

}
